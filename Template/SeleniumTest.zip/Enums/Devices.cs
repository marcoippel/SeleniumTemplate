﻿namespace $safeprojectname$.Enums
{
    public enum Devices
    {
        Iphone4,
        Iphone5,
        Iphone6,
        Ipad,
        Nexus5,
        GalaxyS4,
        GalaxyTab,
        Desktop
    }
}

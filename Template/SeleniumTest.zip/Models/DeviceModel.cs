﻿using System.Drawing;

namespace $safeprojectname$.Models
{
    public class DeviceModel
    {
        public Size ScreenSize { get; set; }
        public string UserAgent { get; set; }
    }
}

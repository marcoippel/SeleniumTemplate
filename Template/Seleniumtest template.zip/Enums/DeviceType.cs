﻿namespace $safeprojectname$.Enums
{
    public enum DeviceType
    {
        Desktop,
        Tablet,
        Mobile
    }
}

﻿using System.Drawing;
using $safeprojectname$.Enums;

namespace $safeprojectname$.Models
{
    public class DeviceModel
    {
        public Size ScreenSize { get; set; }
        public string UserAgent { get; set; }
        public DeviceType Type { get; set; }
    }
}
